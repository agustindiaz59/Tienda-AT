package com.nomEmpresa.nomProyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NomProyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
