package com.nomEmpresa.nomProyecto.modelos;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;

@Entity
public class Administrador {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column
    @NotEmpty
    private String nombre;

    @Column
    @NotEmpty
    private String contrasenia;

    @OneToOne
    @JoinColumn(name = "rol_id")
    private Roles roles;

}
