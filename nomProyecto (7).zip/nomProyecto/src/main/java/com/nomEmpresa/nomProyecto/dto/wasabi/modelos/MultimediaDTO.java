package com.nomEmpresa.nomProyecto.dto.wasabi.modelos;

public record MultimediaDTO(
        String src
) {
}
