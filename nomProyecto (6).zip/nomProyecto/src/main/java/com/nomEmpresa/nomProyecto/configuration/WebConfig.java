package com.nomEmpresa.nomProyecto.configuration;


import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**") // Aplica a todos los endpoints
                .allowedOrigins("http://localhost:3000","http://localhost:5173") // Permite todos los orígenes (puedes especificar)
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS") // Permite todos los métodos HTTP (GET, POST, etc)
                .allowedHeaders("*") // Permite todos los headers
                .exposedHeaders("Authorization")
                .allowCredentials(true)
                .maxAge(3600);
    }
}